package hi.vinnsla;

public interface Reikna {
    int reikna(int a, int b);
}
